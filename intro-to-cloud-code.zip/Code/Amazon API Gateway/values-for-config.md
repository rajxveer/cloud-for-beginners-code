# Function name

GetStartedLambdaProxyIntegration

# Role setting

Create new role from AWS policy templates

# Role name

GetStartedLambdaBasicExecutionRole

# Function code 

(use rest-api-lambda-proxy.js)

# API name

LambdaSimpleProxy

# Settings

REST API
Regional

# Resource

helloworld
/helloworld

# Method

ANY 

# Integration

Lambda proxy

# Deploy to stage

test