# Invoke AWS Lambda Function with custom BASE64 payload

aws lambda invoke --function-name mytestfunction --payload BASE64-ENCODED-STRING response.json

# Invoke AWS Lambda Function

aws lambda invoke --function-name mytestfunction out

